library(testthat)
library(scpi)

test_check("scpi")
